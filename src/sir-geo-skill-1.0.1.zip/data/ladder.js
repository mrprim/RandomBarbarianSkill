module.exports = [
  'mediocre',
  'average',
  'fair',
  'good'
]
