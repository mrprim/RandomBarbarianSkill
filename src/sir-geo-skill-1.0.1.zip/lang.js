module.exports = {
  'en': {
    translation: {
      SKILL_NAME: 'Sir Geo',
      PARTY_TIME_MESSAGE: 'It\'s party time!',
      HELP_MESSAGE: 'Ask me for a party!  Or, you can say exit... Your choice.',
      HELP_REPROMPT: 'What can I help you with?',
      STOP_MESSAGE: 'Goodbye!'
    }
  }
}
